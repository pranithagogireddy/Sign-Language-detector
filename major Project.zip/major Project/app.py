from flask import Flask, Response
import cv2
from cvzone.HandTrackingModule import HandDetector
from cvzone.ClassificationModule import Classifier
import numpy as np
import math
import threading
import queue
from gtts import gTTS
import os
import tempfile
import pygame

app = Flask(__name__)

# Camera and model initialization
cap = cv2.VideoCapture(0)
detector = HandDetector(maxHands=1)
classifier = Classifier(
    r"C:\Users\prani\Programms\web dev\sign language detection\keras_model.h5",
    r"C:\Users\prani\Programms\web dev\sign language detection\labels.txt"
)

labels = ["Dislike", "Goodluck", "Hello", "No", "Ok", "Peace", "Super", "Yes"]
offset = 20
imgSize = 300

# Queue and control variables
speech_queue = queue.Queue()
last_spoken_label = None
is_hand_detected = False
lock = threading.Lock()

# Initialize pygame mixer
pygame.mixer.init()

def speak_label(label):
    try:
        tts = gTTS(text=label, lang='en')
        with tempfile.NamedTemporaryFile(delete=False, suffix=".mp3") as fp:
            temp_path = fp.name
            tts.save(temp_path)

        pygame.mixer.music.load(temp_path)
        pygame.mixer.music.play()
        while pygame.mixer.music.get_busy():
            continue

        os.remove(temp_path)
    except Exception as e:
        print(f"Error generating or playing TTS audio: {e}")

def speech_worker():
    global last_spoken_label
    while True:
        label = speech_queue.get()
        if label and label != last_spoken_label:
            speak_label(label)
            with lock:
                last_spoken_label = label
        speech_queue.task_done()

# Start background thread for speech
threading.Thread(target=speech_worker, daemon=True).start()

def generate_frames():
    global last_spoken_label, is_hand_detected

    while True:
        success, img = cap.read()
        if not success:
            continue

        imgOutput = img.copy()
        hands, img = detector.findHands(img)

        if hands:
            is_hand_detected = True
            hand = hands[0]
            x, y, w, h = hand['bbox']

            hImg, wImg, _ = img.shape
            x1 = max(0, x - offset)
            y1 = max(0, y - offset)
            x2 = min(wImg, x + w + offset)
            y2 = min(hImg, y + h + offset)

            imgWhite = np.ones((imgSize, imgSize, 3), np.uint8) * 255
            imgCrop = img[y1:y2, x1:x2]

            if imgCrop.size == 0:
                continue

            aspectRatio = h / w
            try:
                if aspectRatio > 1:
                    k = imgSize / h
                    wCal = math.ceil(k * w)
                    imgResize = cv2.resize(imgCrop, (wCal, imgSize))
                    wGap = math.ceil((imgSize - wCal) / 2)
                    imgWhite[:, wGap:wCal + wGap] = imgResize
                else:
                    k = imgSize / w
                    hCal = math.ceil(k * h)
                    imgResize = cv2.resize(imgCrop, (imgSize, hCal))
                    hGap = math.ceil((imgSize - hCal) / 2)
                    imgWhite[hGap:hCal + hGap, :] = imgResize
            except:
                continue

            imgWhiteResized = cv2.resize(imgWhite, (224, 224))
            prediction, index = classifier.getPrediction(imgWhiteResized, draw=False)

            if index is not None and 0 <= index < len(labels):
                label = labels[index]

                if label != last_spoken_label:
                    speech_queue.put(label)

                # Draw label
                cv2.rectangle(imgOutput, (x1, y1 - 70), (x2, y1), (0, 255, 0), cv2.FILLED)
                cv2.putText(imgOutput, label, (x1 + 10, y1 - 25),
                            cv2.FONT_HERSHEY_COMPLEX, 1.5, (0, 0, 0), 2)

            # Draw bounding box
            cv2.rectangle(imgOutput, (x1, y1), (x2, y2), (0, 255, 0), 3)

        else:
            if is_hand_detected:
                is_hand_detected = False
                last_spoken_label = None
                pygame.mixer.music.stop()

        # Output stream
        ret, buffer = cv2.imencode('.jpg', imgOutput)
        frame = buffer.tobytes()
        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')

@app.route('/')
def index():
    return "Go to /startdetector to see the video stream."

@app.route('/startdetector')
def start_detector():
    return Response(generate_frames(),
                    mimetype='multipart/x-mixed-replace; boundary=frame')

if __name__ == '__main__':
    app.run(debug=False, host='0.0.0.0', port=5000)
