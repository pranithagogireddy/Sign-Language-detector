document.addEventListener("DOMContentLoaded", function () {
    const themeSelect = document.getElementById("theme");
    const saveButton = document.getElementById("save-settings");
    const resetButton = document.getElementById("reset-settings");

    // Load saved settings from localStorage
    function loadSettings() {
        const settings = JSON.parse(localStorage.getItem("settings")) || {};
        document.getElementById("theme").value = settings.theme || "light";
        document.getElementById("camera-resolution").value = settings.cameraResolution || "720p";
        document.getElementById("fps").value = settings.fps || 30;
        document.getElementById("gesture-sensitivity").value = settings.gestureSensitivity || 5;
        document.getElementById("language").value = settings.language || "english";
        document.getElementById("sound").checked = settings.sound ?? true;
        document.getElementById("model").value = settings.model || "default";
        document.getElementById("hand-tracking").value = settings.handTracking || "single";
        document.getElementById("data-storage").value = settings.dataStorage || "local";
        document.getElementById("auto-update").checked = settings.autoUpdate ?? true;

        // Apply dark mode if selected
        document.body.classList.toggle("dark-mode", settings.theme === "dark");
    }

    // Save settings to localStorage
    saveButton.addEventListener("click", function () {
        const settings = {
            theme: themeSelect.value,
            cameraResolution: document.getElementById("camera-resolution").value,
            fps: document.getElementById("fps").value,
            gestureSensitivity: document.getElementById("gesture-sensitivity").value,
            language: document.getElementById("language").value,
            sound: document.getElementById("sound").checked,
            model: document.getElementById("model").value,
            handTracking: document.getElementById("hand-tracking").value,
            dataStorage: document.getElementById("data-storage").value,
            autoUpdate: document.getElementById("auto-update").checked
        };
        localStorage.setItem("settings", JSON.stringify(settings));
        alert("Settings saved successfully!");
    });

    // Reset settings to default
    resetButton.addEventListener("click", function () {
        localStorage.removeItem("settings");
        loadSettings();
        alert("Settings reset to default!");
    });

    // Handle theme change
    themeSelect.addEventListener("change", function () {
        document.body.classList.toggle("dark-mode", themeSelect.value === "dark");
    });

    loadSettings();
});
